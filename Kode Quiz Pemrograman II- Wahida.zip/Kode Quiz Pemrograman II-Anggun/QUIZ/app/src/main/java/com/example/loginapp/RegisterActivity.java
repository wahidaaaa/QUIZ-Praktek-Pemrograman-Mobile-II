package com.example.loginapp;

import android.app.Activity;
import android.os.Bundle;
import android.util.Patterns;
import android.text.TextUtils;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import org.json.JSONObject;

public class RegisterActivity extends Activity {

    private EditText etNama, etEmail, etPassword, etConfirmPassword;
    private Button btnRegister;
    private TextView tvLogin;
    private boolean requestRunning = false;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_register);

        etNama = findViewById(R.id.etNama);
        etEmail = findViewById(R.id.etEmail);
        etPassword = findViewById(R.id.etPassword);
        etConfirmPassword = findViewById(R.id.etConfirmPassword);
        btnRegister = findViewById(R.id.btnRegister);
        tvLogin = findViewById(R.id.tvLogin);

        btnRegister.setOnClickListener(v -> register());

        tvLogin.setOnClickListener(v -> finish());
    }

    private void register() {
        if (requestRunning) return;

        String nama = etNama.getText().toString().trim();
        String email = etEmail.getText().toString().trim();
        String password = etPassword.getText().toString();
        String confirm = etConfirmPassword.getText().toString();

        if (TextUtils.isEmpty(nama)) {
            etNama.setError("Nama wajib diisi");
            etNama.requestFocus();
            return;
        }

        if (nama.length() > 100) {
            etNama.setError("Nama maksimal 100 karakter");
            return;
        }

        if (!Patterns.EMAIL_ADDRESS.matcher(email).matches()
                || email.length() > 150) {
            etEmail.setError("Email tidak valid");
            etEmail.requestFocus();
            return;
        }

        if (password.length() < 8) {
            etPassword.setError(
                    "Password minimal 8 karakter");
            etPassword.requestFocus();
            return;
        }

        if (!password.equals(confirm)) {
            etConfirmPassword.setError(
                    "Konfirmasi password tidak cocok");
            etConfirmPassword.requestFocus();
            return;
        }

        try {
            JSONObject body = new JSONObject();
            body.put("nama", nama);
            body.put("email", email);
            body.put("password", password);

            requestRunning = true;
            btnRegister.setEnabled(false);
            btnRegister.setText("Mendaftarkan...");

            ApiClient.post("register.php", body,
                    (success, message, data) -> {
                        requestRunning = false;
                        btnRegister.setEnabled(true);
                        btnRegister.setText("DAFTAR");

                        Toast.makeText(
                                RegisterActivity.this,
                                message,
                                Toast.LENGTH_LONG
                        ).show();

                        if (success) {
                            finish();
                        }
                    });

        } catch (Exception e) {
            requestRunning = false;
            btnRegister.setEnabled(true);
            btnRegister.setText("DAFTAR");

            Toast.makeText(this, "Terjadi kesalahan",
                    Toast.LENGTH_SHORT).show();
        }
    }
}
