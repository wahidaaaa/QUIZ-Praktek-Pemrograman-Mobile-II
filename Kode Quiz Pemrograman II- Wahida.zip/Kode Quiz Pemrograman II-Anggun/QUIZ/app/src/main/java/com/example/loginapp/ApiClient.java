package com.example.loginapp;

import android.os.AsyncTask;

import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.io.ByteArrayOutputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.nio.charset.StandardCharsets;

public class ApiClient {

    // Gunakan IP komputer jika aplikasi dijalankan di HP fisik.
    // Jika menggunakan emulator Android Studio, gunakan 10.0.2.2.
    private static final String BASE_URL =
            "http://192.168.1.11/login_api/";

    public interface Callback {
        void onResult(boolean success, String message,
                      JSONObject data);
    }

    public static void post(String endpoint,
                            JSONObject body,
                            Callback callback) {

        new AsyncTask<Void, Void, JSONObject>() {

            String errorMessage = "Tidak dapat terhubung ke server";

            @Override
            protected JSONObject doInBackground(Void... params) {
                HttpURLConnection connection = null;

                try {
                    URL url = new URL(BASE_URL + endpoint);
                    connection = (HttpURLConnection) url.openConnection();

                    connection.setRequestMethod("POST");
                    connection.setConnectTimeout(10000);
                    connection.setReadTimeout(10000);
                    connection.setDoOutput(true);
                    connection.setRequestProperty(
                            "Content-Type",
                            "application/json; charset=UTF-8"
                    );
                    connection.setRequestProperty(
                            "Accept", "application/json"
                    );

                    byte[] bytes = body.toString()
                            .getBytes(StandardCharsets.UTF_8);

                    try (OutputStream output = connection.getOutputStream()) {
                        output.write(bytes);
                    }

                    int status = connection.getResponseCode();

                    InputStream stream = (status >= 200 && status < 400)
                            ? connection.getInputStream()
                            : connection.getErrorStream();

                    String responseText = "";

                    if (stream != null) {
                        try (InputStream input = stream;
                             ByteArrayOutputStream buffer =
                                     new ByteArrayOutputStream()) {

                            byte[] data = new byte[1024];
                            int length;

                            while ((length = input.read(data)) != -1) {
                                buffer.write(data, 0, length);
                            }

                            responseText = buffer.toString("UTF-8");
                        }
                    }

                    if (responseText.trim().isEmpty()) {
                        errorMessage = "Respons server kosong. HTTP "
                                + status
                                + ". Periksa register.php dan logika API.";
                        return null;
                    }

                    JSONObject json;

                    try {
                        json = new JSONObject(responseText);
                    } catch (Exception e) {
                        errorMessage = "Respons server bukan JSON. HTTP "
                                + status + ". Isi respons: "
                                + responseText.substring(
                                0, Math.min(180, responseText.length())
                        );
                        return null;
                    }

                    json.put("_http_status", status);
                    return json;

                } catch (Exception e) {
                    errorMessage = "Koneksi gagal: " + e.getMessage();
                    return null;

                } finally {
                    if (connection != null) {
                        connection.disconnect();
                    }
                }
            }

            @Override
            protected void onPostExecute(JSONObject result) {
                if (result == null) {
                    callback.onResult(false, errorMessage, null);
                    return;
                }

                boolean success = result.optBoolean("success", false);
                String message = result.optString(
                        "message", "Respons server tidak memiliki pesan"
                );

                callback.onResult(
                        success,
                        message,
                        result.optJSONObject("data")
                );
            }

        }.executeOnExecutor(AsyncTask.THREAD_POOL_EXECUTOR);
    }
}
