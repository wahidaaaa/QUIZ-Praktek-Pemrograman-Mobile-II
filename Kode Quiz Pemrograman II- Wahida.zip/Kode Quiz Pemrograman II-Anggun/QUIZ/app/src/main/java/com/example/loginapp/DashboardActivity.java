package com.example.loginapp;

import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.view.View;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

public class DashboardActivity extends AppCompatActivity {

    private TextView tvGreeting;
    private TextView tvEmail;

    private SharedPreferences preferences;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        setContentView(R.layout.activity_dashboard);

        preferences = getSharedPreferences(
                "login_session",
                MODE_PRIVATE
        );

        tvGreeting = findViewById(R.id.tvGreeting);
        tvEmail = findViewById(R.id.tvEmail);

        tampilkanDataPengguna();
        aturMenu();
        aturNavigasi();
    }

    private void tampilkanDataPengguna() {
        // Sesuaikan nama key jika berbeda pada MainActivity.
        String nama = preferences.getString("nama", "Pengguna");
        String email = preferences.getString("email", "");

        if (nama == null || nama.trim().isEmpty()) {
            nama = "Pengguna";
        }

        tvGreeting.setText("Halo, " + nama + "!");

        if (email != null && !email.trim().isEmpty()) {
            tvEmail.setText(email);
        } else {
            tvEmail.setText("Selamat datang kembali");
        }
    }

    private void aturMenu() {
        findViewById(R.id.menuCustomers).setOnClickListener(
                new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        tampilkanPesan(
                                "Menu Pelanggan",
                                "Halaman data pelanggan belum dibuat."
                        );
                    }
                }
        );

        findViewById(R.id.menuProducts).setOnClickListener(
                new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        tampilkanPesan(
                                "Menu Produk",
                                "Halaman produk belum dibuat."
                        );
                    }
                }
        );

        findViewById(R.id.menuRevenue).setOnClickListener(
                new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        tampilkanPesan(
                                "Menu Pendapatan",
                                "Halaman transaksi belum dibuat."
                        );
                    }
                }
        );

        findViewById(R.id.menuStatistics).setOnClickListener(
                new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        tampilkanPesan(
                                "Menu Statistik",
                                "Halaman laporan belum dibuat."
                        );
                    }
                }
        );
    }

    private void aturNavigasi() {
        findViewById(R.id.navHome).setOnClickListener(
                new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        tampilkanPesan(
                                "Beranda",
                                "Kamu sedang berada di dashboard."
                        );
                    }
                }
        );

        findViewById(R.id.navActivity).setOnClickListener(
                new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        tampilkanPesan(
                                "Aktivitas",
                                "Riwayat aktivitas belum dibuat."
                        );
                    }
                }
        );

        findViewById(R.id.navNotifications).setOnClickListener(
                new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        tampilkanPesan(
                                "Notifikasi",
                                "Belum ada halaman notifikasi."
                        );
                    }
                }
        );

        findViewById(R.id.navProfile).setOnClickListener(
                new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        tampilkanProfil();
                    }
                }
        );
    }

    private void tampilkanProfil() {
        String nama = preferences.getString("nama", "Pengguna");
        String email = preferences.getString("email", "-");

        new androidx.appcompat.app.AlertDialog.Builder(this)
                .setTitle("Profil Pengguna")
                .setMessage(
                        "Nama: " + nama + "\n\n" +
                                "Email: " + email
                )
                .setPositiveButton("Tutup", null)
                .setNegativeButton("Logout", (dialog, which) -> logout())
                .show();
    }

    private void tampilkanPesan(String judul, String pesan) {
        new androidx.appcompat.app.AlertDialog.Builder(this)
                .setTitle(judul)
                .setMessage(pesan)
                .setPositiveButton("OK", null)
                .show();
    }

    private void logout() {
        preferences.edit().clear().apply();

        Intent intent = new Intent(
                DashboardActivity.this,
                MainActivity.class
        );

        intent.setFlags(
                Intent.FLAG_ACTIVITY_NEW_TASK |
                        Intent.FLAG_ACTIVITY_CLEAR_TASK
        );

        startActivity(intent);
        finish();
    }
}
