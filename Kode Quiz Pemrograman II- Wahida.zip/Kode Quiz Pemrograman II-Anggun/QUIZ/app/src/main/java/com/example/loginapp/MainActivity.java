package com.example.loginapp;

import android.app.Activity;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.text.TextUtils;
import android.util.Patterns;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import org.json.JSONObject;

public class MainActivity extends Activity {

    private EditText etEmail, etPassword;
    private Button btnLogin;
    private TextView tvRegister;
    private boolean requestRunning = false;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        SharedPreferences pref =
                getSharedPreferences("login_session", MODE_PRIVATE);

        if (pref.getBoolean("logged_in", false)) {
            openDashboard();
            return;
        }

        setContentView(R.layout.activity_main);

        etEmail = findViewById(R.id.etEmail);
        etPassword = findViewById(R.id.etPassword);
        btnLogin = findViewById(R.id.btnLogin);
        tvRegister = findViewById(R.id.tvRegister);

        btnLogin.setOnClickListener(v -> login());

        tvRegister.setOnClickListener(v ->
                startActivity(new Intent(
                        MainActivity.this,
                        RegisterActivity.class
                )));
    }

    private void login() {
        if (requestRunning) return;

        String email = etEmail.getText().toString().trim();
        String password = etPassword.getText().toString();

        if (!Patterns.EMAIL_ADDRESS.matcher(email).matches()) {
            etEmail.setError("Masukkan email yang valid");
            etEmail.requestFocus();
            return;
        }

        if (TextUtils.isEmpty(password)) {
            etPassword.setError("Password wajib diisi");
            etPassword.requestFocus();
            return;
        }

        try {
            JSONObject body = new JSONObject();
            body.put("email", email);
            body.put("password", password);

            requestRunning = true;
            btnLogin.setEnabled(false);
            btnLogin.setText("Memproses...");

            ApiClient.post("login.php", body,
                    (success, message, data) -> {
                        requestRunning = false;
                        btnLogin.setEnabled(true);
                        btnLogin.setText("LOGIN");

                        if (success && data != null) {
                            SharedPreferences pref =
                                    getSharedPreferences(
                                            "login_session",
                                            MODE_PRIVATE);

                            pref.edit()
                                    .putBoolean("logged_in", true)
                                    .putString("nama",
                                            data.optString("nama"))
                                    .putString("email",
                                            data.optString("email"))
                                    .apply();

                            openDashboard();
                        } else {
                            Toast.makeText(
                                    MainActivity.this,
                                    message,
                                    Toast.LENGTH_LONG
                            ).show();
                        }
                    });

        } catch (Exception e) {
            requestRunning = false;
            btnLogin.setEnabled(true);
            btnLogin.setText("LOGIN");
            Toast.makeText(this, "Terjadi kesalahan",
                    Toast.LENGTH_SHORT).show();
        }
    }

    private void openDashboard() {
        Intent intent = new Intent(this, DashboardActivity.class);
        intent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK
                | Intent.FLAG_ACTIVITY_CLEAR_TASK);
        startActivity(intent);
        finish();
    }

    @Override
    protected void onResume() {
        super.onResume();
        if (etPassword != null) {
            etPassword.setText("");
        }
    }
}