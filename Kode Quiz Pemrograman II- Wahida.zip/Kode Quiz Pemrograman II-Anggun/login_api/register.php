
<?php
require_once __DIR__ . '/config.php';

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    http_response_code(405);
    response(false, 'Gunakan metode POST');
}

$data = inputJson();

$nama = $data['nama'] ?? '';
$email = $data['email'] ?? '';
$password = $data['password'] ?? '';

if (!is_string($nama) ||
    !is_string($email) ||
    !is_string($password)) {
    http_response_code(422);
    response(false, 'Format data tidak valid');
}

$nama = trim($nama);
$email = strtolower(trim($email));

if ($nama === '' ||
    strlen($nama) > 100 ||
    !filter_var($email, FILTER_VALIDATE_EMAIL) ||
    strlen($email) > 150 ||
    strlen($password) < 8) {
    http_response_code(422);
    response(false, 'Nama, email, atau password tidak valid. Password minimal 8 karakter.');
}

try {
    $hash = password_hash($password, PASSWORD_DEFAULT);

    $stmt = $conn->prepare(
        'INSERT INTO users (nama, email, password) VALUES (?, ?, ?)'
    );

    $stmt->bind_param('sss', $nama, $email, $hash);
    $stmt->execute();
    $stmt->close();

    response(true, 'Registrasi berhasil');

} catch (mysqli_sql_exception $e) {
    if ((int) $e->getCode() === 1062) {
        http_response_code(409);
        response(false, 'Email sudah terdaftar');
    }

    error_log('Register error: ' . $e->getMessage());
    http_response_code(500);
    response(false, 'Terjadi kesalahan database');
}
