<?php 
require 'config.php'; 
if ($_SERVER['REQUEST_METHOD'] !== 'POST') { 
http_response_code(405); 
response(false, 'Gunakan metode POST'); 
} 
$data = inputJson(); 
$email = strtolower(trim($data['email'] ?? '')); 
$password = $data['password'] ?? ''; 
if (!filter_var($email, FILTER_VALIDATE_EMAIL) || 
!is_string($password)) { 
http_response_code(422); 
response(false, 'Email atau password tidak valid'); 
} 
$stmt = $conn->prepare( 
'SELECT id, nama, email, password FROM users WHERE email = ? LIMIT 1' 
); 
$stmt->bind_param('s', $email); 
$stmt->execute(); 
$user = $stmt->get_result()->fetch_assoc(); 
if (!$user || !password_verify($password, $user['password'])) { 
http_response_code(401); 
response(false, 'Email atau password salah'); 
} 
response(true, 'Login berhasil', [ 
'id' => (int)$user['id'], 
'nama' => $user['nama'], 
'email' => $user['email'] 
]); 
?>